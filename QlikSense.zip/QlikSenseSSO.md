---
title: Qlik Sense学习笔记之单点登录
date: 2019-03-24 13:18:45
updated: 2019-03-24 13:18:45
categories:
	- BI
	- Qlik Sense
tags:
	- BI
	- Qlik Sense
---
## Qlik Sense学习笔记之单点登录

### 1. 前端接口方式

	test(){
        $.ajax({
          method: 'GET',
          url: 'http://ip:port/interface',
          data: {
            eid: '',
            _Account: "itcode",
          },
          success: function (result) {
            console.log(result);
            let arr = JSON.parse(result).data.data.senseUrl.split('?');
            vm.qlikTicket = arr[1]
          }
        });
      },

数据返回结果格式如下：

	{
	    "data": {
	        "code": 200,
	        "data": {
	            "senseUrl": "http://域名/sense/app/9f3b6c30-98df-4aab-a602-1184b0950857?qlikTicket=0ECQkHshAlKCtCrO&eId="
	        },
	        "ip": "域名"
	    }
	}

只需要关心 data.ip 以及 data.data 里的 qlikTicket 即可，将 ip 替换并将 qlikTicket 拼接到辛振维所给的的 URL 中就可以访问了。

如果出现报错：

	Access to XMLHttpRequest at 'http://ip:port/interface?eid=&_Account=zhangsan' from origin 'http://localhost:8080' has been blocked by CORS policy: The 'Access-Control-Allow-Origin' header contains multiple values '*, *', but only one is allowed.

是因为浏览器没有解决跨域问题，解决方法参考下面网址：

[https://www.cnblogs.com/laden666666/p/5544572.html](https://www.cnblogs.com/laden666666/p/5544572.html "Chrome浏览器的跨域设置")

重新打开浏览器访问就就可以了。  

但是对每一个用户都让其设置跨域是不现实的，即 使用前端方式有一定的弊端，所以推荐使用后台接口的方式来实现。  

### 2. 后台接口方式

#### 2.1 获取证书

首先需要从 Sense 服务器上获取到认证证书，提供自己电脑的计算机全名（右键 "我的电脑" -> 单击 "属性" -> 查看计算机全名，eg：xxxxx）或者服务器 IP，将获取到的证书放在本地路径下，修改 SSO.properties 文件中相关属性的值

	CERTFOLDER： 值为本地存放证书的路径或服务器上存放证书的路径
	PROXYCERT： client.jks
	PROXYCERTPASS： 由开发人员提供
	ROOTCERT： root.jks
	ROOTCERTPASS： 由开发人员提供

#### 2.2 修改后台函数

主要函数如下，查看路径为： /SenseSSO/splitJointUrl  

其余函数下载压缩包查看，下载链接如下：

<!-- [https://pan.enn.cn/l/Y0TM4b](https://pan.enn.cn/l/Y0TM4b "Qlick Sense 集成开发资料")  提取密码：sjzt -->

	@Controller
	@RequestMapping(value = {"/SenseSSO" })
	public class SenseSSOController {
		/**
		 * @Title: splitJointUrl
		 * @Description: 拼接senseurl
		 * @param id
		 *            数据库id（对应数据库中的sense url）
		 * @param ldapTicket
		 *            LDAP中员工ticket
		 * @return 拼接之后的url
		 */
		@RequestMapping(value = "splitJointUrl")
		@ResponseBody
		public String splitJointUrl(HttpServletRequest request,HttpServletResponse response) {
			String uri = request.getRequestURI();
			StringBuffer url = request.getRequestURL();
			String _Account = request.getParameter("_Account");
			APIRequestModel _APIRequestModel = new APIRequestModel();
			PropertiesHelper _PropertiesHelper = new PropertiesHelper();
			//String _Token = null;
			response.addHeader("Access-Control-Allow-Origin", "*");
			SenseHelper _SenseHelper = new SenseHelper();
			SenseUserModel senseUserModel = new SenseUserModel();
			String _SenseUrl="";
			try {
				// 访问数据库获得id对应的Sense中的url
				_SenseUrl = _PropertiesHelper.getProfileValue("SENSEURL") + "?qlikTicket=";
				System.out.println(_Account);
				senseUserModel.setUserId(_Account);
				senseUserModel.setUserDirectory(_PropertiesHelper.getProfileValue("USERDIRECTORY"));
			} catch (Exception e) {
				_APIRequestModel.setCode(400);
				_APIRequestModel.setMessage(e.getMessage());
			}
			SenseUserModel _SenseUserModel = null;
			int ip=1;
			String ipString="";
			
			for(int i=0;i<3;i++){
				try {
					// 获取sense中ticket
					_SenseUserModel = _SenseHelper.GetSenseTicket(senseUserModel,ip);
					if(ip==1){
						//ipString="http://encndc2clra19.addom.xinaogroup.com";
						ipString = _PropertiesHelper.getProfileValue("IP");
					}else if(ip==2){
						//ipString="http://encndc2clra20.addom.xinaogroup.com";
						ipString = _PropertiesHelper.getProfileValue("IP2");
					}/*else{
					//ipString="http://encndc2clra18.addom.xinaogroup.com";
					ipString = _PropertiesHelper.getProfileValue("SENSEURL");
					}*/
					_APIRequestModel.setIp(ipString);
				} catch (Exception e) {
					_APIRequestModel.setCode(400);
					_APIRequestModel.setMessage(e.getMessage());
				}
				
				if (_SenseUserModel != null) {
					// 拼接url
					_SenseUrl += _SenseUserModel.getTicket();
					Map<String, String> map = new HashMap<>();
					map.put("senseUrl", _SenseUrl + "&eId=" + eid);
					_APIRequestModel.setData(map);
					_APIRequestModel.setCode(200);
				} else {
					_APIRequestModel.setCode(400);
					_APIRequestModel.setMessage("获取Sense中的Ticket失败！");
				}
				if(_APIRequestModel != null && _APIRequestModel.getCode()==200){
					break;
				}
				ip++;
			}
			JSONObject obj = new JSONObject();
			obj.put("data", _APIRequestModel);
			return obj.toJSONString();
		}
	}

前端传给后台只需要传一个 _Account 参数，值为用户的 itcode，该函数会自动帮用户登录到 sense 中，并且获取到对应的服务器 ip 以及对应的 ticket，服务器的 ip 并不一定是一样的，原因在于 sense 登录的负载均衡。该函数返回一个 object 对象，格式及内容如下：

	{
	    "data": {
	        "code": 200,
	        "data": {
	            "senseUrl": "http://encndc2sens01.addom.xinaogroup.com/sense/app/9f3b6c30-98df-4aab-a602-1184b0950857?qlikTicket=0ECQkHshAlKCtCrO&eId="
	        },
	        "ip": "http://encndc2sens01.addom.xinaogroup.com"
	    }
	}

只需要关心 data.ip 以及 data.data 里的 qlikTicket 即可，将 ip 替换并将 qlikTicket 拼接到辛振维所给的的 URL 中就可以访问了。